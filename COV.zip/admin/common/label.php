<?php

$label["id"]        = "ID";
$label["titulo"]    = "Título";
$label["fecha"]     = "Fecha";
$label["imagen"]    = "Imagen";
$label["muestra"]   = "Muestra";
$label["fecha_creacion"]   = "Fecha Creación";
$label["creado_por"]   = "Creado Por";
$label["contenido"]   = "Contenido";
$label["accion"]   = "Acción";
$label["subtitulo"] = "Subtítulo";
$label["autor"]     = "Autor";






?>